---@meta

---@source UnityEngine.VRModule.dll
---@class UnityEngine.XR.WSA.RemoteDeviceVersion: System.Enum
---@source UnityEngine.VRModule.dll
---@field V1 UnityEngine.XR.WSA.RemoteDeviceVersion
---@source UnityEngine.VRModule.dll
---@field V2 UnityEngine.XR.WSA.RemoteDeviceVersion
---@source UnityEngine.VRModule.dll
CS.UnityEngine.XR.WSA.RemoteDeviceVersion = {}

---@source 
---@param value any
---@return UnityEngine.XR.WSA.RemoteDeviceVersion
function CS.UnityEngine.XR.WSA.RemoteDeviceVersion:__CastFrom(value) end
