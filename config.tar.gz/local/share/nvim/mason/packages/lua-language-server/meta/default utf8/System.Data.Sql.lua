---@meta

---@source System.Data.dll
---@class System.Data.Sql.SqlDataSourceEnumerator: System.Data.Common.DbDataSourceEnumerator
---@source System.Data.dll
---@field Instance System.Data.Sql.SqlDataSourceEnumerator
---@source System.Data.dll
CS.System.Data.Sql.SqlDataSourceEnumerator = {}

---@source System.Data.dll
---@return DataTable
function CS.System.Data.Sql.SqlDataSourceEnumerator.GetDataSources() end


---@source System.Data.dll
---@class System.Data.Sql.SqlNotificationRequest: object
---@source System.Data.dll
---@field Options string
---@source System.Data.dll
---@field Timeout int
---@source System.Data.dll
---@field UserData string
---@source System.Data.dll
CS.System.Data.Sql.SqlNotificationRequest = {}
