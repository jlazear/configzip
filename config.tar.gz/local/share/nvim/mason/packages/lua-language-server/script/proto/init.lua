local proto   = require 'proto.proto'

return proto
