local version = require 'version'
print(version.getVersion())
