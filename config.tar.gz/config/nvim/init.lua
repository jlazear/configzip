require "options"
require "keymaps"
require "Lazy"
require "autocommands"
